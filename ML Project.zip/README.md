You can find our final trained model and mlruns folder on our github:
https://github.com/a80-abbasi/ML_Project
We couldn't upload it due to quera file size limit